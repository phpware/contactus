<?php

  namespace App\Controllers;
  use App\Library\Database as DB;
  use App\Models\Admin;
  use App\Models\Contact;
  use App\Models\Sent;
  use App\Models\Slider;
  use App\Models\Option;
  use App\Models\Page;
  use \Gregwar\Captcha\PhraseBuilder;

  class AdminController extends Controller
  {

    private $session;

    private static $allowed_slug_types = ['page', 'contact'];

    /**
     * @method __construct
     * Sınıf kurucu fonksiyonudur. Burada sayfa yüklenmeden önceki
     * yapılacak işlemleri yaptırabilirsiniz.
     **/
    public function __construct()
    {

      // @TODO (...)

    }

    /**
     * @method get_slug
     * @param string $slug
     * @param string $type
     * Bir kalıcı bağlantı kontrol eder ve oluşturur.
     **/
    private static function get_slug($slug, $type, $old = '')
    {
      if (!in_array($type, self::$allowed_slug_types))
        return false;

      $q = DB::query('SELECT * FROM slugs WHERE slug = ?', [$slug])->first();

      if ($old)
      {
          if ($old === $slug && $q)
          {
            return true;
          }
          elseif ($old === $slug && !$q)
          {
            return DB::query('UPDATE slugs SET slug = ?, type = ? WHERE slug = ?', [$slug, $type, $old]);
          }
          elseif (!$q)
          {
            return DB::query('UPDATE slugs SET slug = ?, type = ? WHERE slug = ?', [$slug, $type, $old]);
          }
          else
          {
            return false;
          }
      }
      else
      {
        if ($q)
        {
          return false;
        }
        else
        {
          return DB::query('INSERT INTO slugs SET slug = ?, type = ?', [$slug, $type]);
        }
      }
    }

    /**
     * @method index
     * Kontrolcü sayfa.
     **/
    public function index()
    {

      if (Admin::auth())
        redirect(route('admin.dashboard'));
      else
        redirect(route('admin.login'));

    }

    /**
     * @method login
     * Giriş yap sayfası.
     **/
    public function login()
    {

      if (Admin::auth())
        redirect(route('admin.dashboard'));

        $data = DB::query("SELECT * FROM sessions WHERE ip = ?", [getRealIP()])->first();
        if ($data->attempts >= 20 && $data->last_attempt < date('Y-m-d H:i:s', strtotime('-15 Minutes')))
          DB::query("UPDATE sessions SET expiry = ?, last_attempt = ?, attempts = ? WHERE ip = ?", [null, null, 0, getRealIP()]);
        elseif ($data->attempts >= 20 && $data->expiry && strtotime($data->expiry) >= time())
          $banned = strtotime($data->expiry);
        elseif ($data->attempts >= 20 && $data->expiry && $data->expiry < time())
          DB::query("UPDATE sessions SET attempts = 0, last_attempt = ?, expiry = ? WHERE ip = ?", [null, null, getRealIP()]);
        elseif ($data->attempts >= 20 && !$data->expiry)
          DB::query("UPDATE sessions SET expiry = ? WHERE ip = ?", [date('Y-m-d H:i:s', strtotime('+15 Minutes')), getRealIP()]);

      parent::view('admin/auth/login', ['ref' => $_SESSION['ref'] ?? '', 'banned' => $banned]);
      unset($_SESSION['ref']);
    }

    /**
     * @method actionLogin
     * Giriş yapma POST sayfasıdır.
     **/
    public function actionLogin()
    {

      $data = DB::query("SELECT * FROM sessions WHERE ip = ?", [getRealIP()])->first();

      if ($data->attempts >= 20)
        back();
      if (!($data->attempts >= 20 && $data->expiry && strtotime($data->expiry) >= time()))
        DB::query("UPDATE sessions SET attempts = attempts + 1, last_attempt = ? WHERE ip = ?", [date('Y-m-d H:i:s'), getRealIP()]);


      if (Admin::auth())
        redirect(route('admin.dashboard'));

      $captcha = input('captcha');
      if (!PhraseBuilder::comparePhrases($_SESSION['phrase'], $captcha))
      {
        Admin::log('Geçersiz CAPTCHA doğrulaması yapıldı.');
        flash('error', 'Güvenlik kodu geçerli değil. Lütfen tekrar deneyiniz.');
        back()->withInput();
      }

      $status = Admin::login(input('email'), input('password'));

      if (!$status)
      {
        flash('error', 'Geçersiz admin bilgileri. Lütfen bilgilerinizi kontrol ediniz.');
        back();
      }

      $refTo = false;
      $ref = input('ref');
      if ($ref)
      {
        $refLink = base64_decode($ref);
        if (filter_var($refLink, FILTER_VALIDATE_URL))
        {
          $data = parse_url($refLink)['host'];
          if ($data === getenv('HTTP_HOST'))
            $refTo = $refLink;
          else
            $refTo = false;
        }
        else
          $refTo = false;

      }

      if ($refTo)
        redirect($refTo);
      else
        redirect(route('admin.dashboard'));

    }

    /**
     * @method actionLogout
     * Çıkış yapma POST sayfasıdır.
     **/
    public function actionLogout()
    {

      if (!Admin::auth())
        redirect(route('admin.dashboard'));

      Admin::logout();

      redirect(route('admin.login'));

    }

    /**
     * @method dashboard
     * Pano sayfasıdır.
     **/
    public function dashboard()
    {

      if (!Admin::auth())
      {
        $_SESSION['ref'] = base64_encode(url(ltrim(ENV_REQUEST_URI, '/')));
        redirect(route('admin.login'));
      }

      $stats['guests'] = DB::query('SELECT COUNT(*) AS TOTAL FROM sessions WHERE last_activity >= ?', [date('Y-m-d H:i:s', strtotime('-15 Minutes'))])->first()->TOTAL;
      $stats['forms'] = DB::query('SELECT COUNT(*) AS TOTAL FROM sents')->first()->TOTAL;

      parent::view('admin/dashboard', ['stats' => $stats]);

    }

    /**
     * @method dashboard
     * Pano sayfasıdır.
     **/
    public function changePassword()
    {

      if (!Admin::auth())
      {
        $_SESSION['ref'] = base64_encode(url(ltrim(ENV_REQUEST_URI, '/')));
        redirect(route('admin.login'));
      }

      Admin::log('Parola değiştirme sayfasına girdi. ID: '.$id);

      parent::view('admin/change_password');

    }

    /**
     * @method actionChangePassword
     * Parola değiştirme POST sayfasıdır.
     **/
    public function actionChangePassword()
    {

      if (!Admin::auth())
        redirect(route('admin.login'));

      $new_password = input('password');
      $check_password = input('check-password');

      if ($new_password !== $check_password)
      {
        flash('error', 'Parolalar eşleşmiyor.');
        back();
      }

      Admin::log('Parolasını güncelledi.');
      Admin::update(Admin::$activeUser->id, ['password' => password_hash($new_password, PASSWORD_DEFAULT)]);

      redirect(route('admin.login'));

    }

    /**
     * @method logs
     * Günlük kayıtları sayfasıdır.
     **/
    public function logs()
    {

      if (!Admin::auth())
      {
        $_SESSION['ref'] = base64_encode(url(ltrim(ENV_REQUEST_URI, '/')));
        redirect(route('admin.login'));
      }

      Admin::log('Günlük sayfasına girdi. ID: '.$id);

      parent::view('admin/logs');

    }

    /**
     * @method forms
     * Form sayfasıdır.
     **/
    public function forms()
    {

      if (!Admin::auth())
      {
        $_SESSION['ref'] = base64_encode(url(ltrim(ENV_REQUEST_URI, '/')));
        redirect(route('admin.login'));
      }

      Admin::log('Formlar sayfasına girdi. ID: '.$id);

      parent::view('admin/forms');

    }

    /**
     * @method sents
     * Form gönderileri sayfasıdır.
     **/
    public function sents()
    {

      if (!Admin::auth())
      {
        $_SESSION['ref'] = base64_encode(url(ltrim(ENV_REQUEST_URI, '/')));
        redirect(route('admin.login'));
      }

      DB::query('UPDATE sents SET viewed = 1');
      Admin::log('Gönderiler sayfasına girdi.');

      parent::view('admin/sents');

    }

    /**
     * @method sliders
     * Slider sayfasıdır.
     **/
    public function sliders()
    {

      if (!Admin::auth())
      {
        $_SESSION['ref'] = base64_encode(url(ltrim(ENV_REQUEST_URI, '/')));
        redirect(route('admin.login'));
      }

      Admin::log('Slider sayfasına girdi. ID: '.$id);

      parent::view('admin/sliders');

    }

    /**
     * @method pages
     * Page sayfasıdır.
     **/
    public function pages()
    {

      if (!Admin::auth())
      {
        $_SESSION['ref'] = base64_encode(url(ltrim(ENV_REQUEST_URI, '/')));
        redirect(route('admin.login'));
      }

      Admin::log('Sayfalar sayfasına girdi. ID: '.$id);

      parent::view('admin/pages');

    }

    /**
     * @method sents
     * Form gönderileri sayfasıdır.
     **/
    public function show($id)
    {

      if (!Admin::auth())
      {
        $_SESSION['ref'] = base64_encode(url(ltrim(ENV_REQUEST_URI, '/')));
        redirect(route('admin.login'));
      }

      $e = DB::query('SELECT * FROM sents WHERE viewed = ?', ['0'])->get();
      if (count($e) === 1 && $e[0]->id === $id)
      {
        DB::query('UPDATE sents SET viewed = 1');
      }

      $sent = Sent::get($id);
      if (!$sent)
        redirect(route('admin.sents'));
      $form = Contact::get($sent->form);
      $inputs = [];

      foreach (json_decode($form->inputs, true) ?? [] as $v)
        $inputs[$v['name']] = $v['label'];

      Admin::log('Gönderi sayfasına girdi. ID: '.$id);

      parent::view('admin/show', ['i' => $sent, 'inputs' => $inputs]);

    }

    /**
     * @method editForm
     * Form düzenleme sayfasıdır.
     **/
    public function print($id)
    {

      if (!Admin::auth())
      {
        $_SESSION['ref'] = base64_encode(url(ltrim(ENV_REQUEST_URI, '/')));
        redirect(route('admin.login'));
      }

      $sent = Sent::get($id);

      if (!$sent)
        redirect(route('admin.forms'));

      $form = Contact::get($sent->form);

      $inputs = [];
      foreach (json_decode($form->inputs, true) ?? [] as $v)
        $inputs[$v['name']] = $v['label'];

      Admin::log('Yazdırma sayfasına girdi. ID: '.$id);

      parent::view('admin/print', ['i' => $sent, 'inputs' => $inputs]);

    }

    /**
     * @method options
     * Form düzenleme sayfasıdır.
     **/
    public function options()
    {

      if (!Admin::auth())
      {
        $_SESSION['ref'] = base64_encode(url(ltrim(ENV_REQUEST_URI, '/')));
        redirect(route('admin.login'));
      }

      $options = Option::all();

      Admin::log('Ayarlar sayfasına girdi. ID: '.$id);

      parent::view('admin/options', ['i' => $options]);

    }

    /**
     * @method addSlider
     * Slider oluşturma sayfasıdır..
     **/
    public function addSlider()
    {

      if (!Admin::auth())
      {
        $_SESSION['ref'] = base64_encode(url(ltrim(ENV_REQUEST_URI, '/')));
        redirect(route('admin.login'));
      }

      Admin::log('Slider ekleme sayfasına girdi. ID: '.$id);

      parent::view('admin/slider/add');

    }

    /**
     * @method addSlider
     * Slider oluşturma sayfasıdır..
     **/
    public function addPage()
    {

      if (!Admin::auth())
      {
        $_SESSION['ref'] = base64_encode(url(ltrim(ENV_REQUEST_URI, '/')));
        redirect(route('admin.login'));
      }

      Admin::log('Sayfa ekleme sayfasına girdi. ID: '.$id);

      parent::view('admin/page/add');

    }

    /**
     * @method addForm
     * Form oluşturma sayfasıdır..
     **/
    public function addForm()
    {

      if (!Admin::auth())
      {
        $_SESSION['ref'] = base64_encode(url(ltrim(ENV_REQUEST_URI, '/')));
        redirect(route('admin.login'));
      }

      Admin::log('Form ekleme sayfasına girdi. ID: '.$id);

      parent::view('admin/form/add');

    }

    /**
     * @method editForm
     * Form düzenleme sayfasıdır.
     **/
    public function editForm($id)
    {

      if (!Admin::auth())
      {
        $_SESSION['ref'] = base64_encode(url(ltrim(ENV_REQUEST_URI, '/')));
        redirect(route('admin.login'));
      }

      $contact = Contact::get($id);

      if (!$contact)
        redirect(route('admin.forms'));

      Admin::log('Form düzenleme sayfasına girdi. ID: '.$id);

      parent::view('admin/form/edit', ['i' => $contact]);

    }

    /**
     * @method editSlider
     * Slider düzenleme sayfasıdır.
     **/
    public function editSlider($id)
    {

      if (!Admin::auth())
      {
        $_SESSION['ref'] = base64_encode(url(ltrim(ENV_REQUEST_URI, '/')));
        redirect(route('admin.login'));
      }

      $slider = Slider::get($id);

      if (!$slider)
        redirect(route('admin.forms'));

      Admin::log('Slider düzenleme sayfasına girdi. ID: '.$id);

      parent::view('admin/slider/edit', ['i' => $slider]);

    }

    /**
     * @method editPage
     * Sayfa düzenleme sayfasıdır..
     **/
    public function editPage($id)
    {

      if (!Admin::auth())
      {
        $_SESSION['ref'] = base64_encode(url(ltrim(ENV_REQUEST_URI, '/')));
        redirect(route('admin.login'));
      }

      Admin::log('Sayfa düzenleme sayfasına girdi. ID: '.$id);

      $page = Page::get($id);
      if (!$page)
        back();

      parent::view('admin/page/edit', ['i' => $page]);

    }

    /**
     * @method actionAddForm
     * Form ekleme POST sayfası.
     **/
    public function actionAddForm()
    {

      if (!Admin::auth())
        redirect(route('admin.login'));

      $inputNames = $_REQUEST['inputNames'];
      $inputTypes = $_REQUEST['inputTypes'];
      $data = $_REQUEST['data'];

      $inputs = [];

      foreach ($inputNames as $key => $input)
      {

        $dataKey = $key * 2;
        if (!isset($inputTypes[$key]) || !isset($data[$dataKey]))
        {
          flash('error', 'Hatalı form gönderdiniz. Lütfen tekrar deneyiniz.');
          back();
        }

        $inputs[] = [
          'name' => permalink($input),
          'type' => $inputTypes[$key],
          'label' => $input,
          'required' => $data[$dataKey]['optional'] == 'on' ? true : false,
          'data' => $data[$dataKey],
        ];

      }

      $inputs = json_encode($inputs);
      $metas = json_encode($_REQUEST['metas']);
      $title = substr(input('title'), 0, 255);
      $slug = permalink(substr(input('slug'), 0, 255));

      if (!self::get_slug($slug, 'contact'))
      {
        flash('error', 'Bu kalıcı bağlantı zaten kullanılıyor. Lütfen başka bir kalıcı bağlantı deneyin.');
        back();
      }

      if (
      Contact::create([
        'title' => $title,
        'slug' => $slug,
        'inputs' => $inputs,
        'metas' => $metas,
        'showOnMenu' => input('showOnMenu'),
      ])
      )
        Admin::log('Yeni form eklendi.');
      else
        Admin::log('Yeni form eklenmeye çalışılırken hata oluştu.');

      redirect(route('admin.forms'));

    }

    /**
     * @method actionAddPage
     * Sayfa ekleme POST sayfası.
     **/
    public function actionAddPage()
    {

      if (!Admin::auth())
        redirect(route('admin.login'));

      $metas = json_encode($_REQUEST['metas']);
      $title = substr(input('title'), 0, 255);
      $slug = permalink(substr(input('slug'), 0, 255));
      $content = input('content');
      $showOnMenu = input('showOnMenu');

      if (!self::get_slug($slug, 'page'))
      {
        flash('error', 'Bu kalıcı bağlantı zaten kullanılıyor. Lütfen başka bir kalıcı bağlantı deneyin.');
        back();
      }

      if (
      Page::create([
        'title' => $title,
        'slug' => $slug,
        'content' => $content,
        'metas' => $metas,
        'showOnMenu' => $showOnMenu,
      ])
      )
        Admin::log('Yeni sayfa eklendi.');
      else
        Admin::log('Yeni sayfa eklenmeye çalışılırken hata oluştu.');

      redirect(route('admin.pages'));

    }

    /**
     * @method actionAddSlider
     * Slider ekleme POST sayfası.
     **/
    public function actionAddSlider()
    {

      if (!Admin::auth())
        redirect(route('admin.login'));

        $path = urlencode($form->title).'/sliders';
        $imageFileType = strtolower(pathinfo($_FILES['image']["name"], PATHINFO_EXTENSION));
        $target_dir = ENV_APP_ROOT."/public/uploads/{$path}/";
        $target_file = $target_dir . time()."-slider-".rand(1000000,9999999).".{$imageFileType}";
        $uploadOk = 1;

        if (file_exists($target_file)) {
          flash('error', 'Bu isimde bir dosya zaten var.');
          back();
        }

        if ($_FILES['image']["size"] > 5000000) {
          flash('error', 'Dosya boyutu en fazla 50MiB olabilir.');
          back();
        }

        if ($uploadOk == 0) {
          flash('error', 'Dosya yüklenemedi.');
          back();
        }
        else
        {
          if (!move_uploaded_file($_FILES['image']["tmp_name"], $target_file))
          {
            flash('error', 'Dosya yüklenemedi.');
            back();
          }

          $image = url(preg_replace('@^'.preg_quote(ENV_APP_ROOT).'/@', null, $target_file));
        }

      $link = input('link');
      $span = input('top-title');
      $h2 = input('big-title');
      $p = input('bottom-title');
      $a = input('button-text');

      if (
      Slider::create([
        'image' => $image,
        'link' => $link,
        'span' => $span,
        'h2' => $h2,
        'p' => $p,
        'a' => $a,
      ])
      )
        Admin::log('Yeni slider eklendi.');
      else
        Admin::log('Yeni slider eklenmeye çalışılırken hata oluştu.');

      redirect(route('admin.sliders'));

    }

    /**
     * @method actionEditForm
     * Form düzenleme POST sayfası.
     **/
    public function actionEditForm()
    {

      if (!Admin::auth())
        redirect(route('admin.login'));

      $inputNames = $_REQUEST['inputNames'];
      $inputTypes = $_REQUEST['inputTypes'];
      $data = $_REQUEST['data'];

      $inputs = [];

      foreach ($inputNames as $key => $input)
      {

        $dataKey = $key * 2;

        if (!isset($inputTypes[$key]) || !isset($data[$dataKey]))
        {
          flash('error', 'Hatalı form gönderdiniz. Lütfen tekrar deneyiniz.');
          back();
        }

        $inputs[] = [
          'name' => permalink($input),
          'type' => $inputTypes[$key],
          'label' => $input,
          'required' => $data[$dataKey]['optional'] == 'on' ? true : false,
          'data' => $data[$dataKey],
        ];

      }

      $old = Contact::get(input('id'));

      $inputs = json_encode($inputs);
      $metas = json_encode($_REQUEST['metas']);
      $title = substr(input('title'), 0, 255);
      $slug = permalink(substr(input('slug'), 0, 255));

      if (!self::get_slug($slug, 'contact', $old->slug))
      {
        flash('error', 'Bu kalıcı bağlantı zaten kullanılıyor. Lütfen başka bir kalıcı bağlantı deneyin.');
        back();
      }

      if (
      Contact::update([
        'title' => $title,
        'slug' => $slug,
        'inputs' => $inputs,
        'metas' => $metas,
        'showOnMenu' => input('showOnMenu'),
      ], [['id',input('id')]])
      )
      {
        flash('success', 'Başarıyla güncellendi.');
        Admin::log('Form güncellendi.');
      }
      else
      {
        flash('error', 'Düzenlenirken bir sorun oluştu. Lütfen formunuzu kontrol edip, tekrar gönderin.');
        Admin::log('Form güncellenmeye çalışılırken bir hata oluştu.');
      }

      back();

    }

    /**
     * @method actionEditPage
     * Sayfa düzenleme POST sayfası.
     **/
    public function actionEditPage()
    {

      if (!Admin::auth())
        redirect(route('admin.login'));

      $id = input('id');
      $metas = json_encode($_REQUEST['metas']);
      $title = substr(input('title'), 0, 255);
      $slug = permalink(substr(input('slug'), 0, 255));
      $content = input('content');
      $showOnMenu = input('showOnMenu');

      $old = Page::get(input('id'));

      if (!self::get_slug($slug, 'page', $old->slug))
      {
        flash('error', 'Bu kalıcı bağlantı zaten kullanılıyor. Lütfen başka bir kalıcı bağlantı deneyin.');
        back();
      }

      if (
      Page::update([
        'title' => $title,
        'slug' => $slug,
        'content' => $content,
        'metas' => $metas,
        'showOnMenu' => $showOnMenu,
      ], [['id', input('id')]])
      )
        Admin::log('Sayfa düzenlendi. ID: '.$id);
      else
        Admin::log('Sayfa düzenlenmeye çalışılırken hata oluştu. ID: '.$id);

      back();

    }

    /**
     * @method actionEditSlider
     * Slider ekleme POST sayfası.
     **/
    public function actionEditSlider()
    {

      if (!Admin::auth())
        redirect(route('admin.login'));

        if (isset($_FILES['image']) && !empty($_FILES['image']['name']))
        {
          $path = urlencode($form->title).'/sliders';
          $imageFileType = strtolower(pathinfo($_FILES['image']["name"], PATHINFO_EXTENSION));
          $target_dir = ENV_APP_ROOT."/public/uploads/{$path}/";
          $target_file = $target_dir . time()."-slider-".rand(1000000,9999999).".{$imageFileType}";
          $uploadOk = 1;

          if (file_exists($target_file)) {
            flash('error', 'Bu isimde bir dosya zaten var.');
            back();
          }

          if ($_FILES['image']["size"] > 5000000) {
            flash('error', 'Dosya boyutu en fazla 50MiB olabilir.');
            back();
          }

          if ($uploadOk == 0) {
            flash('error', 'Dosya yüklenemedi.');
            back();
          }
          else
          {
            if (!move_uploaded_file($_FILES['image']["tmp_name"], $target_file))
            {
              flash('error', 'Dosya yüklenemedi.');
              back();
            }

            $image = url(preg_replace('@^'.preg_quote(ENV_APP_ROOT).'/@', null, $target_file));
          }
        }
        else
        {
          $image = false;
        }

        $link = input('link');
        $span = input('top-title');
        $h2 = input('big-title');
        $p = input('bottom-title');
        $a = input('button-text');

        $args = [
                  'link' => $link,
                  'span' => $span,
                  'h2' => $h2,
                  'p' => $p,
                  'a' => $a,
                ];

        if ($image)
          $args['image'] = $image;

        if (
        Slider::update($args, [['id', input('id')]])
        )
          Admin::log('Mevcut slider güncellendi.');
        else
          Admin::log('Mevcut slider güncellenmeye çalışılırken hata oluştu.');

        back();

    }

    /**
     * @method actionAddForm
     * Form silme sayfası.
     **/
    public function actionDeleteForm($id)
    {

      if (!Admin::auth())
        redirect(route('admin.login'));

      $e = Contact::get($id);
      if (!$e)
        back();

      $slug = $e->slug;
      DB::query('DELETE FROM slugs WHERE slug = ?, type = ?', [$slug, 'contact']);
      Admin::log('Bir form silindi. Silinen form ID: '.$id);
      back();

    }

    /**
     * @method actionDeleteSlider
     * Slider silme sayfası.
     **/
    public function actionDeleteSlider($id)
    {

      if (!Admin::auth())
        redirect(route('admin.login'));

      Slider::delete($id);
      Admin::log('Bir slider silindi. Silinen slider ID: '.$id);
      back();

    }

    /**
     * @method actionDeletePage
     * Sayfa silme sayfası.
     **/
    public function actionDeletePage($id)
    {

      if (!Admin::auth())
        redirect(route('admin.login'));

      $e = Page::get($id);
      if (!$e)
        back();

      $slug = $e->slug;
      DB::query('DELETE FROM slugs WHERE slug = ? AND type = ?', [$slug, 'page']);

      Admin::log('Bir sayfa silindi. Silinen sayfa ID: '.$id);
      back();

    }

    /**
     * @method actionAddSlider
     * Slider silme sayfası.
     **/
    public function actionUpdate()
    {

      if (!Admin::auth())
        redirect(route('admin.login'));

      if (!empty($_FILES['logo']['name']))
      {
        $imageFileType = strtolower(pathinfo($_FILES['logo']["name"], PATHINFO_EXTENSION));
        $target_dir = ENV_APP_ROOT."/public/uploads/";
        $target_file = $target_dir . time()."-logo-".rand(1000000,9999999).".{$imageFileType}";
        $uploadOk = 1;

        if (file_exists($target_file)) {
          flash('error', 'Bu isimde bir dosya zaten var.');
          back();
        }

        if ($_FILES['logo']["size"] > 5000000) {
          flash('error', 'Dosya boyutu en fazla 50MiB olabilir.');
          back();
        }

        if ($uploadOk == 0) {
          flash('error', 'Dosya yüklenemedi.');
          back();
        }
        else
        {
          if (!move_uploaded_file($_FILES['logo']["tmp_name"], $target_file))
          {
            flash('error', 'Dosya yüklenemedi.');
            back();
          }

        $logo = url(preg_replace('@^'.preg_quote(ENV_APP_ROOT).'/@', null, $target_file));

        Option::update(['value' => $logo], [['name' => 'logo']]);
        }
      }

      Option::update(['value' => input('telegram')], [['name', 'telegram']]);
      Option::update(['value' => input('telegram-api-key')], [['name', 'telegram-api-key']]);
      Option::update(['value' => input('telegram-chat-id')], [['name', 'telegram-chat-id']]);

      Admin::log('Ayarlar güncellendi.');
      back();

    }

  }
