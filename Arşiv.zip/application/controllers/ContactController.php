<?php

  namespace App\Controllers;
  use App\Library\Database as DB;
  use App\Models\Contact;
  use App\Models\Option;
  use App\Models\Slug;
  use App\Models\Page;
  use \Gregwar\Captcha\CaptchaBuilder;
  use \Gregwar\Captcha\PhraseBuilder;

  class ContactController extends Controller
  {

    /**
     * @method __construct
     * Sınıf kurucu fonksiyonudur. Burada sayfa yüklenmeden önceki
     * yapılacak işlemleri yaptırabilirsiniz.
     **/
    public function __construct()
    {
      // @TODO (...)

      if (ENV_REQUEST_URI !== '/get-captcha')
        DB::query("REPLACE INTO sessions SET ip = ?, last_activity = ?, route = ?", [getRealIP(), date('Y-m-d H:i:s'), ENV_REQUEST_URI]);
    }

    /**
     * @method error404
     **/
    public function error404()
    {

      parent::view('404');

    }

    /**
     * @method getCaptcha
     * CAPTCHA resmini basar.
     **/
    public function getCaptcha()
    {
      $builder = new CaptchaBuilder;
      $builder->build();

      $_SESSION['phrase'] = $builder->getPhrase();

      header('Content-type: image/jpeg');
      $builder->output();
    }

    /**
     * @method index
     * Sayfa: Ana Sayfa
     **/
    public function index()
    {

      $data['title'] = 'İletişim Formu';
      $data['sliders'] = DB::query('SELECT * FROM sliders')->get();
      $data['contacts'] = Contact::all();
      $data['pages'] = Page::all();

      parent::view('index', $data);

    }

    /**
     * @method form
     * Sayfa: Form Sayfası
     **/
    public function form($slug)
    {

      $slugItem = Slug::getBy('slug', $slug);
      if (!$slugItem)
        return redirect('404');

      if ($slugItem->type === 'contact')
      {
        $form = Contact::getBy('slug', $slugItem->slug);

        if (!$form)
          return redirect('404');

        $data['title'] = 'İletişim Formu';
        $data['sliders'] = DB::query('SELECT * FROM sliders')->get();
        $data['contacts'] = Contact::all();
        $data['pages'] = Page::all();
        $data['form'] = $form;


        parent::view('form', $data);
      }
      elseif ($slugItem->type === 'page')
      {
        $form = Page::getBy('slug', $slugItem->slug);

        if (!$form)
          return redirect('404');

        if (!isset($_SESSION['pages']) XOR (isset($_SESSION['pages']) && !in_array($slugItem->slug, $_SESSION['pages'])))
        {
          Page::update(['view_count' => $form->view_count + 1], [['slug', $slugItem->slug]]);
          $_SESSION['pages'][] = $slugItem->slug;
        }

        $data['title'] = $form->title;
        $data['page'] = $form;
        $data['contacts'] = Contact::all();
        $data['pages'] = Page::all();

        parent::view('page', $data);
      }
      else return redirect('404');
    }

    /**
     * @method store
     **/
    public function store()
    {
      $id = intval(input('id'));
      $form = Contact::get($id);

      if (!$form)
        return redirect('404');

      $captcha = input('captcha');
      if (!PhraseBuilder::comparePhrases($_SESSION['phrase'], $captcha))
      {
        flash('error', 'Güvenlik kodu geçerli değil. Lütfen tekrar deneyiniz.');
        back()->withInput();
      }

      $inputs = json_decode($form->inputs);
      $json = [];

      foreach ($inputs as $input => $value)
      {
        if (in_array($value->type, ['image', 'archive']))
        {

          if (!is_dir(ENV_APP_ROOT."/public/uploads/{$form->slug}"))
            mkdir(ENV_APP_ROOT."/public/uploads/{$form->slug}");

          if (!is_dir(ENV_APP_ROOT."/public/uploads/{$form->slug}/{$value->name}"))
            mkdir(ENV_APP_ROOT."/public/uploads/{$form->slug}/{$value->name}");

          if ($value->data->optional == 'on' && !$_FILES[$value->name]['name'])
            continue;
          elseif ($value->data->optional != 'on' && !$_FILES[$value->name]['name'])
          {
            die(2);
            flash('error', sprintf('%s alanı boş olmamalıdır.', $value->label));
            back()->withInput();
          }

          $path = urlencode($form->slug).'/'.urlencode($value->name);
          $imageFileType = strtolower(pathinfo($_FILES[$value->name]["name"], PATHINFO_EXTENSION));
          $target_dir = ENV_APP_ROOT."/public/uploads/{$path}/";
          $target_file = $target_dir . time()."-{$form->slug}-{$value->name}-".rand(1000000,9999999).".{$imageFileType}";
          $uploadOk = 1;

          if (file_exists($target_file)) {
            flash('error', 'Bu isimde bir dosya zaten var.');
            back();
          }

          if ($_FILES[$value->name]["size"] > 5000000) {
            flash('error', 'Dosya boyutu en fazla 50MiB olabilir.');
            back();
          }

          if ($uploadOk == 0) {
            flash('error', 'Dosya yüklenemedi.');
            back();
          }
          else
          {
            if (!move_uploaded_file($_FILES[$value->name]["tmp_name"], $target_file))
            {
              flash('error', 'Dosya yüklenemedi.');
              back();
            }

            $json[$value->name] = url(preg_replace('@^'.preg_quote(ENV_APP_ROOT).'/@', null, $target_file));
          }
        }
        else
        {
          if (!is_string($_REQUEST[$value->name] ?? ''))
          {
            flash('error', 'Geçersiz bir form gönderdiniz. Lütfen tekrar deneyiniz.');
            back();
          }
          $json[$value->name] = input($value->name);
        }

        if ($value->data->optional !== 'on' && empty($json[$value->name]))
        {
          flash('error', sprintf('%s alanı boş olmamalıdır.', $value->label));
          back()->withInput();
        }

      }
      $json = json_encode($json);


      if (DB::query("INSERT INTO sents SET form = :form, form_name = :form_name, inputs = :inputs, from_ip = :from_ip", ['form' => $form->id, 'form_name' => $form->title, 'inputs' => $json, 'from_ip' => getRealIP()]))
      {
        if (Option::getBy('name', 'telegram')->value)
        {

          $inputs = [];

          foreach (json_decode($form->inputs, true) ?? [] as $v)
            $inputs[$v['name']] = $v['label'];

          $chat_id = Option::getBy('name', 'telegram-chat-id')->value;
          $token = Option::getBy('name', 'telegram-api-key')->value;

          $text = "Yeni bir form gönderildi!\n\n";
          $text .= "*Form:* $form->title\n\n";
          foreach (json_decode($json, true) as $n => $value)
            $text .= "*{$inputs[$n]}:* {$value}\n";

          $url = sprintf("https://api.telegram.org/bot%s/sendmessage", $token);
          $params = [
            'parse_mode' => 'markdown',
            'chat_id' => $chat_id,
            'text' => $text,
          ];
          $query = http_build_query($params);
          $generatedURL = "{$url}?{$query}";

          file_get_contents($generatedURL);

        }
        flash('success', 'Form başarıyla gönderildi.');
      }
      else
        flash('error', 'Form gönderilirken bir sorun oluştu. Lütfen tekrar deneyiniz.');

      back();

    }

  }
