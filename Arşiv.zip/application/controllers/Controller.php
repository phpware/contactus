<?php

  namespace App\Controllers;

  define('VIEWS', ENV_APP_DIR_APP . '/views');

  class Controller
  {

    public function view(string $template, array $args = [])
    {

      extract($args);
      include ENV_APP_DIR_APP . "/views/{$template}.php";

    }

  }
