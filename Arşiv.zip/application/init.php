<?php

  namespace App;
  use App\Library\Route;
  use App\Library\Database;

  session_start();
  ob_start();

  $datetime = require_once ENV_APP_DIR_CONFIG . '/datetime.php';

  date_default_timezone_set($datetime['current_timezone']);
  setlocale(LC_TIME, $datetime['current_locale']);

  $libraries = glob(ENV_APP_DIR_APP . '/library/*.php');
  foreach ($libraries as $library)
    require_once $library;

  $models = glob(ENV_APP_DIR_APP . '/models/*.php');
  foreach ($models as $model)
    require_once $model;

  call_user_func_array([Database::class, 'setup'], require_once(ENV_APP_DIR_CONFIG . '/database.php'));

  Route::insertRoutes(require_once(ENV_APP_DIR_APP . '/routes.php'));
  Route::runRoute();
