<?php

  namespace App\Library;

  class Database
  {

    private static $PDO, $query;

    public static function setup($host, $dbname, $username, $password, $opts)
    {

      try
      {
        $dsn = sprintf("mysql:host=%s;dbname=%s", $host, $dbname);
        self::$PDO = new \PDO($dsn, $username, $password, $opts);
      }
      catch (\PDOException $e)
      {
        die($e->getMessage());
      }

    }

    public static function query($queryString, $params = [])
    {

      try
      {
        self::$query = self::$PDO->prepare($queryString);
        self::$query->execute($params);

        return new self;
      }
      catch (\PDOException $e)
      {
        die($e->getMessage());
      }

    }

    public static function self()
    {

      return self::$PDO;

    }

    public function first()
    {

      try
      {
        return self::$query->fetch();
      }
      catch (\PDOException $e)
      {
        die($e->getMessage());
      }

    }

    public function get()
    {

      try
      {
        return self::$query->fetchAll();
      }
      catch (\PDOException $e)
      {
        die($e->getMessage());
      }

    }

  }
