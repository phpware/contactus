<?php

  namespace App\Library;
  use App\Library\Database as DB;

  abstract class Model
  {

    /**
     * @method getById
     * @param mixed $id
     * ID'ye göre nesne getirir.
     **/
    public static function get($id)
    {

      $id = intval($id);
      return DB::query(sprintf('SELECT * FROM %s WHERE id = :id', static::$table), ['id' => $id])->first();

    }

    /**
     * @method getById
     * @param mixed $id
     * ID'ye göre nesne getirir.
     **/
    public static function getBy($by, $value)
    {

      return DB::query(sprintf('SELECT * FROM %s WHERE %s = :value', static::$table, $by), ['value' => $value])->first();

    }

    /**
     * @method getById
     * @param mixed $id
     * Tüm nesneleri getirir.
     **/
    public static function all()
    {

      return DB::query(sprintf('SELECT * FROM %s', static::$table))->get();

    }

    /**
     * @method create
     * @param mixed $params
     * Yeni bir nesne oluşturur.
     **/
    public static function create($params)
    {

      $prm = [];
    	$insert = '';
    	foreach ($params as $col => $param)
    	{
    		$insert .= "`{$col}` = ?, ";
    		$prm[] = $param;
    	}
    	$insert = rtrim($insert, ', ');

    	$queryString = "INSERT INTO %s SET %s";
    	$query = sprintf($queryString, static::$table, $insert);

      DB::query($query, $prm);
      return DB::self()->lastInsertId();

    }

    /**
     * @method update
     * @param array $params
     * @param array $where
     * Mevcut nesneyi günceller.
     **/
    public static function update($params, $where)
    {

    	$prm = [];
    	$update = '';
    	foreach ($params as $col => $param)
    	{
    		$update .= "`{$col}` = ?, ";
    		$prm[] = $param;
    	}
    	$update = rtrim($update, ', ');

    	$conds = '';
    	foreach ($where as $param)
    	{
    		$col = $param[0] ?? $param['col'];
    		if (count($param) === 2)
    		{
    			$del = 'AND';
    			$val = $param[1] ?? $param['value'];
    		}
    		elseif (count($param) === 3)
    		{
    			$del = $param[1] ?? $param['delimiter'];
    			$val = $param[2] ?? $param['value'];
    		}
    		else continue;

    		$conds .= "`{$col}` = ? {$del} ";
    		$prm[] = $val;
    	}

    	if ($conds)
    		$conds = rtrim($conds, " {$del} ");
    	else
    		$conds = 1;

    	$queryString = "UPDATE %s SET %s WHERE %s";
    	$query = sprintf($queryString, static::$table, $update, $conds);

      return DB::query($query, $prm);
    }

    /**
     * @method delete
     * @param mixed $id
     * Mevcut nesneyi siler.
     **/
    public static function delete($id)
    {

      return DB::query(sprintf("DELETE FROM %s WHERE id = :id", static::$table), ['id' => $id]);

    }

  }
