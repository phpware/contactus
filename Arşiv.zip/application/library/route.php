<?php

  namespace App\Library;

  class Route
  {

    /**
     * @var array $routes
     * Class özelinde saklanacak route bilgileri.
     **/
    private static $routes = [];

    /**
     * @method insertRoutes
     * @param array $routes
     * Route sınıfına route bilgilerini kaydeder.
     **/
    public static function insertRoutes(array $routes)
    {

      self::$routes = $routes;

    }

    /**
     * @method getRouteURL
     * @param string $name
     * @param array $params
     * Kontrollü bir rota URL adresi oluşturur.
     **/
    public static function getRouteURL(string $name, array $params = [])
    {

      $route = $GLOBALS['routes'][$name] ?? false;

      if (!$route)
        return false;

      foreach ($params as $param => $value)
      {

        $param = preg_quote($param);
        $route = preg_replace("@\{{$param}(.*?)\}@", $value, $route);

      }

      if (preg_match("@\{([a-z0-9\_\:\;\,\(\)]+)\}@", $route))
        return false;
      else
        return $route;

    }

    /**
     * @method handleParams
     * @param mixed $route
     * @param mixed $url
     * Rota parametrelerini işler ve döndürür.
     **/
    protected static function handleParams(string $route, string $url)
    {

      $returnData = [];
    	$url = $url != '/' ? ltrim($url, '/') : $url;
    	$regex = preg_replace("@\{([a-z0-9\_\:\;\,\(\)]+)\}@", "(.+)", $route);

    	preg_match_all("@\{([a-z0-9\_\:\;\,\(\)]+)\}@", $route, $data);
    	preg_match("@{$regex}@", $url, $matches);

      if ($data[1])
      {
      	foreach ($data[1] as $key => $param)
      	{

      		$parsed = explode(':', $param);
      		$data = $matches[$key+1] ?? false;

          if (!$data)
            return false;

          $returnData[$parsed[0]] = $data;
      		if (count($parsed) === 2)
      		{
      			$args = explode(';', $parsed[1]);
      			switch ($args[0])
      			{

      				default:

                $return = call_user_func_array(["App\Library\Route\R_{$args[0]}", 'data'], array_merge([$data],explode(',', $fetch[2])));
                if (!$return)
                  return false;

      					foreach ($args as $arg)
      					{
      						if ($arg == $args[0]) continue;

      						preg_match('@(\w+)\((.*?)\)@', $arg, $fetch);

      						$return = call_user_func_array(["App\Library\Route\R_{$args[0]}", $fetch[1]], array_merge([$data],explode(',', $fetch[2])));

      						if (!$return)
      							return false;
      					}

      					break;

      			}

      		}
          else
          {
            $status = false;
          }

      	}

        $status = true;
      }
      else
      {
        $status = $route === $url;
      }

      return ['params' => $returnData, 'status' => $status];

    }

    /**
     * @method runRoute
     * Rota ana işleyicisi.
     **/
    public static function runRoute()
    {
      $GLOBALS['routes'] = [];

      $all = glob(ENV_APP_DIR_APP . "/library/route/*.php");
      foreach ($all as $i)
        require_once $i;

      $params = false;
      foreach (self::$routes as $route => $current)
      {
        $params = self::handleParams($route, ENV_REQUEST_URI);
        if ($params['status'] ?? false)
          break;
      }

      foreach (self::$routes as $route => $ex)
        if ($ex[3] ?? ($ex['name'] ?? false))
          $GLOBALS['routes'][$ex[3] ?? $ex['name']] = $route;

      if (!$params['status'])
        return redirect('404');

      require_once ENV_APP_DIR_APP . "/controllers/Controller.php";
      $all = glob(ENV_APP_DIR_APP . "/controllers/*.php");
      foreach ($all as $i)
      {
        if (strpos('/Controller.php', $i))
          continue;

        require_once $i;
      }

      $controller = $current[0] ?? $current['controller'];
      $method = $current[1] ?? $current['method'];
      $request = $current[2] ?? ($current['request'] ?? 'GET');

      if ($request !== ENV_REQUEST_METHOD)
        return http_response_code(403);

      if (ENV_REQUEST_METHOD === 'POST' && !csrfCheck())
        return http_response_code(403);

      if (ENV_REQUEST_METHOD !== 'POST')
      {
        $GLOBALS['csrf'] = bin2hex(random_bytes(32));
        $_SESSION['csrf'] = $GLOBALS['csrf'];
      }

      $objController = new $controller();
      call_user_func_array([$objController, $method], $params['params']);

    }

  }
