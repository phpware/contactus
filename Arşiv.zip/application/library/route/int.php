<?php

  namespace App\Library\Route;

  class R_Int
  {

    /**
     * @method data
     * @param mixed $queryData
     * Veri tipini sorgular.
     **/
    public static function data($queryData)
    {
      return is_string($queryData);
    }

    /**
     * @method min
     * @param mixed @queryData
     * @param mixed $value
     * Minimum parametre uzunluğunu kontrol eder.
     **/
    public static function min($queryData, $value)
    {

      return $queryData >= $value;

    }

    /**
     * @method max
     * @param mixed @queryData
     * @param mixed $value
     * Maksimum parametre uzunluğunu kontrol eder.
     **/
    public static function max($queryData, $value)
    {

      return $queryData <= $value;

    }

  }
