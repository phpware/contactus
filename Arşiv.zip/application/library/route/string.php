<?php

  namespace App\Library\Route;

  class R_String
  {

    /**
     * @method data
     * @param mixed $queryData
     * Veri tipini sorgular.
     **/
    public static function data($queryData)
    {
      return is_string($queryData);
    }

    /**
     * @method minlength
     * @param mixed $queryData
     * @param mixed $value
     * Minimum parametre uzunluğunu kontrol eder.
     **/
    public static function minlength($queryData, $value)
    {

      return strlen($queryData) >= $value;

    }

    /**
     * @method maxlength
     * @param mixed $queryData
     * @param mixed $value
     * Maksimum parametre uzunluğunu kontrol eder.
     **/
    public static function maxlength($queryData, $value)
    {

      return strlen($queryData) <= $value;

    }

    /**
     * @method maxlength
     * @param mixed $queryData
     * Parametre girdisinin bir sayı olup olmadığını kontrol eder.
     **/
    public static function numeric($queryData)
    {

      return preg_match('@^[0-9]+$@', $queryData);

    }

  }
