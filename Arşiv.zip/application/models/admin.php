<?php

  namespace App\Models;
  use App\Library\Model;
  use App\Library\Database as DB;

  class Admin extends Model
  {

    protected static $table = 'users';
    static $activeUser;

    /**
     * @method user
     * @param string $key
     * Geçerli kullanıcının bilgilerini döndürür.
     **/
    public static function user(string $key)
    {

      return self::$activeUser->$key ?? '';

    }

    /**
     * @param string $input
     * Kullanıcı işlem günlüğüne kayıt basma işlevidir.
     **/
    public static function log(string $input)
    {

      if (!self::Auth())
        $input = "!!! Kimliksiz işlem talebi. Talep: {$input}";

      $date = date('d-m-Y');
      $datetime = date('d-m-Y H:i:s');
      $username = self::$activeUser->email ?? '?';
      $realIP = getRealIP();
      $logFile = fopen(ENV_APP_ROOT . "/logs/admins-{$date}.log", "a+");
      fwrite($logFile, "[{$datetime}][{$realIP}][$username]: {$input}\n");
      fclose($logFile);

      return true;

    }

    /**
     * @return bool
     * Admin girişi yapılıp yapılmadığını kontrol eder.
     **/
    public static function auth()
    {

      $session = $_SESSION['auth'] ?? [];

      if ($session)
      {

        $email = $_SESSION['auth']->email ?? false;
        $password = $_SESSION['auth']->password ?? false;

        if (!$email || !$password) return false;

        $admin = DB::query(sprintf("SELECT * FROM %s WHERE email = ?", self::$table), [$email])->first();

        if ($admin && password_verify($password, $admin->password))
        {
          self::$activeUser = $admin;
          return true;
        }
        else return false;

      }
      else return false;

    }

    /**
     * @method login
     * @param string $email
     * @param string $password
     * Giriş yapma işlevidir.
     **/
    public static function login($email, $password)
    {

      $query = DB::query("SELECT password FROM users WHERE email = ?", [$email])->first();

      if ($query)
      {
        if (password_verify($password, $query->password))
        {

          $_SESSION['auth'] = new \stdClass;
          $_SESSION['auth']->email = $email;
          $_SESSION['auth']->password = $password;

          self::log('Giriş yaptı.');

          DB::query("UPDATE sessions SET attempts = 0 WHERE ip = ?", [getRealIP()]);

          return true;

        }
        else
        {
          self::log(sprintf('Başarısız giriş denemesi. Giriş parametre(leri): [email=%s]', $email));
          return false;
        }
      }
      else
      {
        self::log(sprintf('Başarısız giriş denemesi. Giriş parametre(leri): [email=%s]', $email));
        return false;
      }

    }

    /**
     * @method logout
     * Çıkış yapma işlevidir.
     **/
    public static function logout()
    {

      self::log('Çıkış yaptı.');
      unset($_SESSION['auth']);
      return true;

    }

    public static function update($id, $args)
    {

      $table = self::$table;
      $set = '';
      $params = [];
      foreach ($args as $key => $arg)
      {
        $set .= "{$key} = ?, ";
        $params[] = $arg;
      }
      $set = rtrim($set, ', ');

      DB::query(sprintf('UPDATE %s SET %s WHERE id = %s', $table, $set, $id), $params);

      return boolval(DB::self()->rowCount);

    }

  }
