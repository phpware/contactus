<?php

  namespace App\Models;
  use App\Library\Model;

  class Contact extends Model
  {

    protected static $table = 'contacts';

  }
