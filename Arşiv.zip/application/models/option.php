<?php

  namespace App\Models;
  use App\Library\Model;

  class Option extends Model
  {

    protected static $table = 'options';

  }
