<?php

  namespace App\Models;
  use App\Library\Model;

  class Page extends Model
  {

    protected static $table = 'pages';

  }
