<?php

  namespace App\Models;
  use App\Library\Model;

  class Sent extends Model
  {

    protected static $table = 'sents';

  }
