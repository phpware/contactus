<?php

  namespace App\Models;
  use App\Library\Model;

  class Slider extends Model
  {

    protected static $table = 'sliders';

  }
