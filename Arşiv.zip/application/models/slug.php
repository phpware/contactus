<?php

  namespace App\Models;
  use App\Library\Model;

  class Slug extends Model
  {

    protected static $table = 'slugs';

  }
