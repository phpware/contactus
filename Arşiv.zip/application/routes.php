<?php

/**
 *
 * ÖRNEK ROTA KULLANIMLARI:
 *
 * 'rota/{parametre:VERI_TURU;fonk1(x,y);fonk2(a)}'
 *
 * 'rota/{parametre:VERI_TURU}'
 *
 * 'rota/{parametre}'
 *
 * NOT! ilgili veri türü fonksiyonları, "application/library/route" klasöründe
 * toplanmıştır. Detaylı bilgiler o dosyalarda bulunmaktadır.
 *
 **/

return [

  ## SISTEM
  '/' => [App\Controllers\ContactController::class, 'index'],
  'get-captcha' => [App\Controllers\ContactController::class, 'getCaptcha', 'GET', 'get-captcha'],
  'action' => [App\Controllers\ContactController::class, 'store', 'POST', 'action'],

  ## TEMELLER
  'admin' => [App\Controllers\AdminController::class, 'index', 'GET', 'admin.index'],
  'admin/login' => [App\Controllers\AdminController::class, 'login', 'GET', 'admin.login'],
  'admin/login/ref={ref}' => [App\Controllers\AdminController::class, 'login', 'GET', 'admin.login.withRef'],
  'admin/change-password' => [App\Controllers\AdminController::class, 'changePassword', 'GET', 'admin.change-password'],
  'admin/dashboard' => [App\Controllers\AdminController::class, 'dashboard', 'GET', 'admin.dashboard'],
  'admin/logs' => [App\Controllers\AdminController::class, 'logs', 'GET', 'admin.logs'],
  'admin/forms' => [App\Controllers\AdminController::class, 'forms', 'GET', 'admin.forms'],
  'admin/sents' => [App\Controllers\AdminController::class, 'sents', 'GET', 'admin.sents'],
  'admin/sliders' => [App\Controllers\AdminController::class, 'sliders', 'GET', 'admin.sliders'],
  'admin/pages' => [App\Controllers\AdminController::class, 'pages', 'GET', 'admin.pages'],
  'admin/show/{id:string;numeric();maxlength(50)}' => [App\Controllers\AdminController::class, 'show', 'GET', 'admin.show'],
  'admin/print/{id:string;numeric();maxlength(50)}' => [App\Controllers\AdminController::class, 'print', 'GET', 'admin.print'],
  'admin/options' => [App\Controllers\AdminController::class, 'options', 'GET', 'admin.options'],

  ## FORM
  'admin/form/add' => [App\Controllers\AdminController::class, 'addForm', 'GET', 'admin.form.add'],
  'admin/form/edit/{id:string;numeric();maxlength(50)}' => [App\Controllers\AdminController::class, 'editForm', 'GET', 'admin.form.edit'],

  ## SLIDER
  'admin/slider/add' => [App\Controllers\AdminController::class, 'addSlider', 'GET', 'admin.slider.add'],
  'admin/slider/edit/{id:string;numeric();maxlength(50)}' => [App\Controllers\AdminController::class, 'editSlider', 'GET', 'admin.slider.edit'],

  ## PAGE
  'admin/page/add' => [App\Controllers\AdminController::class, 'addPage', 'GET', 'admin.page.add'],
  'admin/page/edit/{id:string;numeric();maxlength(50)}' => [App\Controllers\AdminController::class, 'editPage', 'GET', 'admin.page.edit'],

  ## ACTIONS
  'admin/action/login' => [App\Controllers\AdminController::class, 'actionLogin', 'POST', 'admin.action.login'],
  'admin/action/change-password' => [App\Controllers\AdminController::class, 'actionChangePassword', 'POST', 'admin.action.change-password'],
  'admin/action/update' => [App\Controllers\AdminController::class, 'actionUpdate', 'POST', 'admin.action.update'],
  'admin/action/logout' => [App\Controllers\AdminController::class, 'actionLogout', 'GET', 'admin.action.logout'],

    ## ACTIONS :: FORM
    'admin/action/form/add' => [App\Controllers\AdminController::class, 'actionAddForm', 'POST', 'admin.action.form.add'],
    'admin/action/form/edit' => [App\Controllers\AdminController::class, 'actionEditForm', 'POST', 'admin.action.form.edit'],
    'admin/action/form/delete/{id:string;numeric();maxlength(50)}' => [App\Controllers\AdminController::class, 'actionDeleteForm', 'GET', 'admin.action.form.delete'],

    ## ACTIONS :: SLIDER
    'admin/action/slider/add' => [App\Controllers\AdminController::class, 'actionAddSlider', 'POST', 'admin.action.slider.add'],
    'admin/action/slider/edit' => [App\Controllers\AdminController::class, 'actionEditSlider', 'POST', 'admin.action.slider.edit'],
    'admin/action/slider/delete/{id:string;numeric();maxlength(50)}' => [App\Controllers\AdminController::class, 'actionDeleteSlider', 'GET', 'admin.action.slider.delete'],

    ## ACTIONS :: PAGE
    'admin/action/page/add' => [App\Controllers\AdminController::class, 'actionAddPage', 'POST', 'admin.action.page.add'],
    'admin/action/page/edit' => [App\Controllers\AdminController::class, 'actionEditPage', 'POST', 'admin.action.page.edit'],
    'admin/action/page/delete/{id:string;numeric();maxlength(50)}' => [App\Controllers\AdminController::class, 'actionDeletePage', 'GET', 'admin.action.page.delete'],

  ## KONTROLLER
  '404' => [App\Controllers\ContactController::class, 'error404', 'GET', '404'],
  '{slug}' => [App\Controllers\ContactController::class, 'form', 'GET', 'form'],

];
