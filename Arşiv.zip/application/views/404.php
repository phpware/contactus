<?php
  include __DIR__ . '/partials/header.php';
?>

        <div id="about" class="page-section">
            <div class="container text-center">
              <h1>404</h1>
              <h2>SAYFA BULUNAMADI</h2>
            </div>
        </div>


<?php
  include __DIR__ . '/partials/footer.php';
?>
<style media="screen">
  .service-item:hover { cursor: default; background: #FFF; }
  .service-item:hover h4 { color: #000 !important; }
  .datacaptcha { width: 50%; margin: 0 auto; }
</style>
