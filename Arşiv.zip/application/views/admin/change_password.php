<?php
  $title = 'Parola Değiştir';
  include __DIR__ . '/partials/header.php';
?>

        <div class="container-fluid px-4">
            <h1 class="mt-4">Şifre Değiştir</h1>

            <form action="<?=route('admin.action.change-password')?>" method="post">
              <?=csrfHiddenInput()?>
              <div class="row w-ort-60 w-100">
                <?php
                  $flash = getFlash('error');
                  if ($flash):
                ?>
                <div class="col-12">
                  <div class="alert alert-danger mt-2">
                    <?=$flash?>
                  </div>
                </div>
                <?php
                  endif;
                ?>
                <div class="col-12 form-group">
                  <label for="new-password" class="control-label">Yeni Parolanız:</label>
                  <input id="new-password" type="password" class="form-control" name="password" autocomplete="new-password" required>
                </div>
                <div class="col-12 form-group mt-3">
                  <label for="check-password" class="control-label">Yeni Parolanızı Doğrulayın:</label>
                  <input id="check-password" type="password" class="form-control" name="check-password" required>
                </div>
                <div class="col-12">
                  <button type="submit" class="btn btn-primary btn-sm mt-3 w-100">PAROLAYI GÜNCELLE</button>
                </div>
              </div>
            </form>
        </div>

<?php
  include __DIR__ . '/partials/footer.php';
?>
<style media="screen">
  @media (min-width: 767px)
  {

    .w-ort-60 { width: 60% !important }

  }
</style>
