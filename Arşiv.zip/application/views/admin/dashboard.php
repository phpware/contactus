<?php
  $title = 'Pano';
  include __DIR__ . '/partials/header.php';
?>

        <div class="container-fluid px-4">
            <div class="row mt-4">
                <div class="col-xl-6 col-md-6">
                    <div class="card bg-primary text-white mb-4">
                        <div class="card-body">Ziyaretçiler</div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            <?=$stats['guests']?>
                            <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-6 col-md-6">
                    <div class="card bg-warning text-white mb-4">
                        <div class="card-body">Gönderilen Formlar</div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            <?=$stats['forms']?>
                            <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="mt-4">


              <h2>SON 10 GÖNDERİ:</h2>

              <table class="table table-striped w-100" id="table">
                <thead class="thead-dark">
                  <tr>
                    <th>No.</th>
                    <th>Form Adı</th>
                    <th></th>
                    <th></th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                  foreach (App\Library\Database::query('SELECT * FROM sents ORDER BY id DESC LIMIT 10')->get() as $i):
                  ?>
                  <tr>
                    <td><?=$i->id?></td>
                    <td><?=$i->form_name?></td>
                    <td>
                      <a href="<?=route('admin.print', ['id' => $i->id])?>" class="btn btn-secondary w-100"><i class="fas fa-print"></i></a>
                    </td>
                    <td>
                      <a href="<?=route('admin.show', ['id' => $i->id])?>" class="btn btn-info w-100"><i class="fas fa-eye"></i></a>
                    </td>
                  </tr>
                  <?php endforeach ?>
                </tbody>
              </table>

            </div>
        </div>

<?php
  include __DIR__ . '/partials/footer.php';
?>
