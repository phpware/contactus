<?php
  $title = 'Form Ekle';
  include ENV_APP_DIR_APP . '/views/admin/partials/header.php';
?>

        <div class="container-fluid px-4">
            <h1 class="mt-4">Yeni Form Ekle</h1>
            <form class="py-3" action="<?=route('admin.action.form.add')?>" method="post">
              <?=csrfHiddenInput()?>
              <?php
                $flash = getFlash('error');
                if ($flash):
              ?>
              <div class="alert alert-danger">
                <?=$flash?>
              </div>
              <?php
                endif;
              ?>
              <div class="form-group mb-2">
                <label for="form-title" class="control-label">Form Başlığı:</label>
                <input id="form-title" type="text" class="form-control" maxlength="255" name="title" required>
              </div>

              <div class="form-group mb-2">
                <label for="form-slug" class="control-label">Form Kalıcı Bağlantısı:</label>
                <input id="form-slug" type="text" class="form-control" maxlength="255" name="slug" required>
              </div>

              <div class="form-group mb-2">
                <label for="form-title" class="control-label">Sayfa Başlığı:</label>
                <input id="form-title" type="text" class="form-control" name="metas[title]" required>
              </div>

              <div class="form-group mb-2">
                <label for="form-title" class="control-label">Sayfa Açıklaması:</label>
                <input id="form-title" type="text" class="form-control" name="metas[description]" required>
              </div>

              <div class="form-group mb-2">
                <label for="form-title" class="control-label">Sayfa Anahtar Kelimeleri:</label>
                <input id="form-title" type="text" class="form-control" name="metas[keywords]" required>
              </div>

              <div class="form-group mb-2">
                <input type="hidden" name="showOnMenu" value="0">
                <input id="form-check" type="checkbox" class="form-check-input" name="showOnMenu" value="1">
                <label for="form-check" class="control-label form-check-label">Menüde Göster</label>
              </div>

              <div class="form-group">

                <a href="#top" id="add-input" class="btn btn-info mb-2">YENİ FORM ALANI EKLE <i class="fas fa-plus"></i></a>

                <div class="input-area">



                </div>

              </div>

              <div class="form-group">

                <button type="submit" class="btn btn-primary btn-lg btn-block w-100">YENİ FORM OLUŞTUR</button>

              </div>

            </form>
        </div>

<?php
  include ENV_APP_DIR_APP . '/views/admin/partials/footer.php';
?>
<script type="text/javascript">

    function deleteItem(that, is_select)
    {

      if (is_select)
      {
        $(that).parent().parent().prev().remove();
        $(that).parent().parent().remove();
      }
      else
      {
        $(that).parent().prev().remove();
        $(that).parent().remove();
      }

    }

  $(function()
  {

    $('#add-input').on('click', function()
    {

      $('.input-area').append("<div class='row'>"+
      "<div class='col-md-6'>"+
      "<input class='form-control mb-3' placeholder='Alan İsmi' name='inputNames[]' required>"+
      "</div>"+
      "<div class='col-md-6'>"+
      "<select class='form-control mb-3 input-class' name='inputTypes[]' required>"+
      "<option value='' selected disabled>Bir alan türü seçin</option>"+
      "<option value='checkbox'>Checkbox</option>"+
      "<option value='email'>E-Posta</option>"+
      "<option value='phone'>Telefon</option>"+
      "<option value='select'>Seçim Kutusu</option>"+
      "<option value='text'>Metin</option>"+
      "<option value='textarea'>Metin Alanı</option>"+
      "<option value='image'>Resim</option>"+
      "<option value='archive'>Arşiv Dosyası</option>"+
      "</div>"+
      "</div>");

    });

    $('body').on('change', '.input-class', function()
    {

      if ($(this).parent().parent().next().hasClass('opts'))
        $(this).parent().parent().next().remove();

      if (!$(this).parent().parent().next().hasClass('opts'))
      {

        switch ($(this).val())
        {

          case 'checkbox':
          case 'text':
          case 'textarea':
          case 'email':
          case 'phone':
          case 'archive':
          case 'image':
          $(this).parent().parent().after("<div class='opts mb-4'>"+
            "<div class='float-left'>"+
            "<input type='hidden' name='data["+$(this).parent().parent().index()+"][optional]' value='off'>"+
            "<input type='checkbox' name='data["+$(this).parent().parent().index()+"][optional]' id='ed-"+$(this).parent().parent().index()+"' class='form-check-input'>"+
            "<label class='form-check-label' for='ed-"+$(this).parent().parent().index()+"'>Opsiyonel</label>"+
            "</div>"+
            "<a href='#' class='text-right text-danger' onclick='deleteItem(this, false);'>Sil</a>"+
            "</div>");
            break;

          case 'select':
          $(this).parent().parent().after("<div class='opts mb-4 row'>"+
            "<div class='col-md-4'>"+
            "<input type='hidden' name='data["+$(this).parent().parent().index()+"][optional]' value='off'>"+
            "<input type='checkbox' name='data["+$(this).parent().parent().index()+"][optional]' id='ed-"+$(this).parent().parent().index()+"' class='form-check-input'>"+
            "<label class='form-check-label' for='ed-"+$(this).parent().parent().index()+"'>Opsiyonel</label>"+
            "</div>"+
            "<div class='col-md-4'>"+
            "<textarea name='data["+$(this).parent().parent().index()+"][datas]' class='form-control' placeholder='Seçim öğeleri (ayırmak için boşluk bırakınız)' required></textarea>"+
            "</div>"+
            "<div class='col-md-4'>"+
            "<a href='#' class='text-right text-danger' onclick='deleteItem(this, true);'>Sil</a>"+
            "</div>"+
            "</div>");
          break;

        }

      }

    });

  });
</script>

<style media="screen">
  .float-left { float: left !important; }
  .text-right { text-align: right !important; display: inherit; }
</style>
<a id="top"></a>
