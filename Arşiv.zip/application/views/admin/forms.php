<?php
  $title = 'Formlar';
  include __DIR__ . '/partials/header.php';
?>

        <div class="container-fluid px-4">
            <h1 class="mt-4">
              Formlar
              <a href="<?=route('admin.form.add')?>" class="btn btn-primary float-right">YENİ OLUŞTUR</a>
            </h1>

            <table class="table table-striped w-100" id="table">
              <thead class="thead-dark">
                <tr>
                  <th>No.</th>
                  <th>Form</th>
                  <th></th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                <?php
                foreach (App\Models\Contact::all() as $i):
                ?>
                <tr>
                  <td><?=$i->id?></td>
                  <td><?=$i->title?></td>
                  <td>
                    <a href="<?=route('admin.form.edit', ['id' => $i->id])?>" class="btn btn-warning btn-block w-100"><i class="fas fa-edit"></i></a>
                  </td>
                  <td>
                    <a href="<?=route('admin.action.form.delete', ['id' => $i->id])?>" class="btn btn-danger btn-block w-100" onclick="return confirm('Bu formu silmek istediğinizden emin misiniz?');"><i class="fas fa-trash"></i></a>
                  </td>
                </tr>
                <?php endforeach ?>
              </tbody>
            </table>

        </div>

<?php
  include __DIR__ . '/partials/footer.php';
?>
<script type="text/javascript">
  $(function()
  {
    $('#table').DataTable({
      "language":{
        "url" : "//cdn.datatables.net/plug-ins/1.10.12/i18n/Turkish.json",
      },
      dom: 'Bfrtip',
        buttons: [
          'copy', 'csv', 'excel', 'pdf', 'print'
        ]
    });
  });
</script>
