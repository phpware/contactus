<?php
  $title = 'Günlük Kayıtları';
  include __DIR__ . '/partials/header.php';
?>

        <div class="container-fluid px-4">
            <h1 class="mt-4">Günlük Kayıtları (en sondan başa)</h1>

            <textarea id="logs" readonly rows="15" cols="100"><?php
                $date = date('d-m-Y');
                $logFile = fopen(ENV_APP_ROOT . "/logs/admins-{$date}.log", "a+");
                $data = fread($logFile, filesize(ENV_APP_ROOT . "/logs/admins-{$date}.log"));
                fclose($logFile);
                $d = explode("\n", $data);
                $r = array_reverse($d);
                foreach ($r as $v)
                  echo htmlEscape($v)."\n";
              ?>
            </textarea>

        </div>

<?php
  include __DIR__ . '/partials/footer.php';
?>
