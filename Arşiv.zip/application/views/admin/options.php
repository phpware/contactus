<?php
  $title = 'Seçenekler';
  include __DIR__ . '/partials/header.php';
?>

        <form action="<?=route('admin.action.update')?>" enctype="multipart/form-data" method="post">
          <?=csrfHiddenInput()?>

          <div class="container-fluid px-4">
              <h1 class="mt-4">
                SİTE AYARLARI
              </h1>

              <div class="container">

                <div class="card mb-3">

                  <div class="card-body">

                    <div class="title form-group">SİTE LOGOSU:</div>
                    <div>
                      <input type="file" accept=".png, .bmp, .gif, .jpg, .jpeg" name="logo" class="form-control" required>
                    </div>

                    <figure class="text-center pt-3">
                      <img style="width: 60%; height: auto; max-height: 400px; object-fit: contain" src="<?=App\Models\Option::getBy('name','logo')->value?>" alt="">
                    </figure>

                  </div>

                </div>

              <div class="card mb-3">

                <div class="card-body">

                  <div class="title form-group">TELEGRAM BİLDİRİMLERİ AKTİF/PASİF:</div>
                  <div>
                    <select class="form-control" name="telegram">
                      <option value="0"<?=App\Models\Option::getBy('name', 'telegram')->value ? '' : ' selected'?>>Pasif</option>
                      <option value="1"<?=App\Models\Option::getBy('name', 'telegram')->value ? ' selected' : ''?>>Aktif</option>
                    </select>
                  </div>

                </div>

              </div>

              <div class="card mb-3">

                <div class="card-body">

                  <div class="title form-group">TELEGRAM API KEY:</div>
                  <div>
                    <input type="text" class="form-control" name="telegram-api-key" value="<?=App\Models\Option::getBy('name','telegram-api-key')->value?>">
                  </div>

                </div>

              </div>

              <div class="card mb-3">

                <div class="card-body">

                  <div class="title form-group">TELEGRAM CHAT ID:</div>
                  <div>
                    <input type="text" class="form-control" name="telegram-chat-id" value="<?=App\Models\Option::getBy('name','telegram-chat-id')->value?>">
                  </div>

                </div>

              </div>

              <div class="card mb-3">

                <div class="card-body">

                  <button type="submit" class="btn btn-primary btn-lg btn-block w-100">AYARLARI GÜNCELLE</button>

                </div>

              </div>


              </div>

          </div>

        </form>

<?php
  include __DIR__ . '/partials/footer.php';
?>
<style media="screen">
  .title {
    font-size: 24px;
    font-weight: bold;
  }
</style>
