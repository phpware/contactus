<?php
  $title = 'Sayfa Ekle';
  include ENV_APP_DIR_APP . '/views/admin/partials/header.php';
?>

        <div class="container-fluid px-4">
            <h1 class="mt-4">Yeni Sayfa Ekle</h1>
            <form class="py-3" enctype="multipart/form-data" action="<?=route('admin.action.page.add')?>" method="post">
              <?=csrfHiddenInput()?>
              <?php
                $flash = getFlash('error');
                if ($flash):
              ?>
              <div class="alert alert-danger">
                <?=$flash?>
              </div>
              <?php
                endif;
              ?>

              <div class="form-group mb-2">
                <label for="form-link2" class="control-label">Sayfa Başlığı</label>
                <input id="form-link2" type="text" class="form-control" maxlength="255" name="title" required>
              </div>

              <div class="form-group mb-2">
                <label for="form-link3" class="control-label">Sayfa Kalıcı Bağlantısı:</label>
                <input id="form-link3" type="text" class="form-control" maxlength="255" name="slug" required>
              </div>

              <div class="form-group mb-2">
                <label for="form-link4" class="control-label">Sayfa Açıklaması</label>
                <input id="form-link4" type="text" class="form-control" name="metas[description]" required>
              </div>

              <div class="form-group mb-2">
                <label for="form-link5" class="control-label">Sayfa Anahtar Kelimeleri</label>
                <input id="form-link5" type="text" class="form-control" name="metas[keywords]" required>
              </div>

              <div class="form-group mb-2">
                <label for="form-link" class="control-label">Sayfa Açıklaması</label>
                <textarea name="content" id="editor1" class="form-control" rows="8" cols="80"></textarea>
              </div>

              <div class="form-group mb-2">
                <input type="hidden" name="showOnMenu" value="0">
                <input id="form-check" type="checkbox" class="form-check-input" name="showOnMenu" value="1">
                <label for="form-check" class="control-label form-check-label">Menüde Göster</label>
              </div>

              <div class="form-group">
                <button type="submit" class="btn btn-primary btn-lg btn-block w-100">YENİ SAYFA OLUŞTUR</button>
              </div>

            </form>
        </div>

<?php
  include ENV_APP_DIR_APP . '/views/admin/partials/footer.php';
?>

<script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>
<script>
  CKEDITOR.replace( 'editor1' );
</script>
<style media="screen">
  .float-left { float: left !important; }
  .text-right { text-align: right !important; display: inherit; }
</style>
<a id="top"></a>
