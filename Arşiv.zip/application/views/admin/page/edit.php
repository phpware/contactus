<?php
  $title = 'Sayfa Düzenle';
  include ENV_APP_DIR_APP . '/views/admin/partials/header.php';
?>

        <div class="container-fluid px-4">
            <h1 class="mt-4">Sayfayı Düzenle</h1>
            <form class="py-3" enctype="multipart/form-data" action="<?=route('admin.action.page.edit')?>" method="post">
              <?=csrfHiddenInput()?>
              <?php
                $flash = getFlash('error');
                if ($flash):
              ?>
              <div class="alert alert-danger">
                <?=$flash?>
              </div>
              <?php
                endif;
              ?>
              <input type="hidden" name="id" value="<?=$i->id?>">

              <div class="form-group mb-2">
                <label for="form-link2" class="control-label">Sayfa Başlığı</label>
                <input id="form-link2" type="text" class="form-control" maxlength="255" value="<?=old('title') ?? ($i->title ?? '')?>" name="title" required>
              </div>

              <div class="form-group mb-2">
                <label for="form-link3" class="control-label">Sayfa Kalıcı Bağlantısı:</label>
                <input id="form-link3" type="text" class="form-control" maxlength="255" name="slug" value="<?=old('slug') ?? ($i->slug ?? '')?>" required>
              </div>

              <div class="form-group mb-2">
                <label for="form-link4" class="control-label">Sayfa Açıklaması</label>
                <input id="form-link4" type="text" class="form-control" name="metas[description]" value="<?=old('metas')['description'] ?? (json_decode($i->metas, true)['description'] ?? '')?>" required>
              </div>

              <div class="form-group mb-2">
                <label for="form-link5" class="control-label">Sayfa Anahtar Kelimeleri</label>
                <input id="form-link5" type="text" class="form-control" name="metas[keywords]" value="<?=old('metas')['keywrods'] ?? (json_decode($i->metas, true)['keywords'] ?? '')?>" required>
              </div>

              <div class="form-group mb-2">
                <label for="form-link" class="control-label">Sayfa Açıklaması</label>
                <textarea name="content" id="editor1" class="form-control" rows="8" cols="80"><?=old('content') ?? ($i->content ?? '')?></textarea>
              </div>

              <div class="form-group mb-2">
                <input type="hidden" name="showOnMenu" value="0">
                <input id="form-check" type="checkbox" class="form-check-input" name="showOnMenu" value="1"<?=$i->showOnMenu ? ' checked' : null?>>
                <label for="form-check" class="control-label form-check-label">Menüde Göster</label>
              </div>

              <div class="form-group">
                <button type="submit" class="btn btn-primary btn-lg btn-block w-100">SAYFAYI DÜZENLE</button>
              </div>

            </form>
        </div>

<?php
  include ENV_APP_DIR_APP . '/views/admin/partials/footer.php';
?>

<script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>
<script>
  CKEDITOR.replace( 'editor1' );
</script>
<style media="screen">
  .float-left { float: left !important; }
  .text-right { text-align: right !important; display: inherit; }
</style>
<a id="top"></a>
