<?php
  $title = 'Sayfalar';
  include __DIR__ . '/partials/header.php';
?>

        <div class="container-fluid px-4">
            <h1 class="mt-4">
              Sayfalar
              <a href="<?=route('admin.page.add')?>" class="btn btn-primary float-right">YENİ OLUŞTUR</a>
            </h1>

            <table class="table table-striped w-100" id="table">
              <thead class="thead-dark">
                <tr>
                  <th width="32px">No.</th>
                  <th>Başlık</th>
                  <th>Görüntüleme</th>
                  <th></th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                <?php
                foreach (App\Models\Page::all() as $i):
                ?>
                <tr>
                  <td><?=$i->id?></td>
                  <td>
                    <b><?=$i->title?></b>
                  </td>
                  <td><?=$i->view_count?></td>
                  <td>
                    <a href="<?=route('admin.page.edit', ['id' => $i->id])?>" class="btn btn-warning w-100"><i class="fas fa-edit"></i></a>
                  </td>
                  <td>
                    <a href="<?=route('admin.action.page.delete', ['id' => $i->id])?>" class="btn btn-danger w-100" onclick="return confirm('Bu formu silmek istediğinizden emin misiniz?');"><i class="fas fa-trash"></i></a>
                  </td>
                </tr>
                <?php endforeach ?>
              </tbody>
            </table>

        </div>

<?php
  include __DIR__ . '/partials/footer.php';
?>
<script type="text/javascript">
  $(function()
  {
    $('#table').DataTable({
      "language":{
        "url" : "//cdn.datatables.net/plug-ins/1.10.12/i18n/Turkish.json",
      },
    });
  });
</script>
