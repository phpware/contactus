<!DOCTYPE html>
<html lang="tr">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <title><?=$title ?? 'Bilinmeyen Sayfa'?> | <?=getenv('HTTP_HOST')?></title>
        <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
        <link href="<?=asset('admin/css/styles.css')?>" rel="stylesheet" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="https://cdn.datatables.net/1.11.3/css/jquery.dataTables.min.css">
        <link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.0.1/css/buttons.dataTables.min.css">
    </head>
    <body class="sb-nav-fixed">
        <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
            <!-- Navbar Brand-->
            <a class="navbar-brand ps-3" href="<?=asset('admin/index.html')?>">Admin Paneli</a>
            <!-- Sidebar Toggle-->
            <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="<?=asset('admin/#!')?>"><i class="fas fa-bars"></i></button>
            <!-- Navbar Search-->
            <form class="d-none d-md-inline-block form-inline ms-auto me-0 me-md-3 my-2 my-md-0">
            </form>
            <!-- Navbar-->
            <ul class="navbar-nav ms-auto ms-md-0 me-3 me-lg-4">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" id="navbarDropdown" href="<?=asset('admin/#')?>" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fas fa-user fa-fw"></i></a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                        <li><a class="dropdown-item" href="<?=route('admin.change-password')?>">Şifre Değiştir</a></li>
                        <li><a class="dropdown-item" href="<?=route('admin.logs')?>">Günlük Kayıtları</a></li>
                        <li><hr class="dropdown-divider" /></li>
                        <li><a class="dropdown-item" href="<?=route('admin.action.logout')?>">Çıkış Yap</a></li>
                    </ul>
                </li>
            </ul>
        </nav>
        <div id="layoutSidenav">
            <div id="layoutSidenav_nav">
                <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                    <div class="sb-sidenav-menu">
                        <div class="nav">
                            <div class="sb-sidenav-menu-heading">ADMİN</div>
                            <a class="nav-link" href="<?=route('admin.dashboard')?>">
                                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                                Pano
                            </a>
                            <div class="sb-sidenav-menu-heading">İÇERİK</div>
                            <a class="nav-link" href="<?=route('admin.forms')?>">
                                <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                                Formlar
                            </a>
                            <a class="nav-link" href="<?=route('admin.sents')?>">
                                <div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>
                                Gönderiler
                                <?php
                                if ($a = App\Library\Database::query('SELECT * FROM sents WHERE viewed = ?', ['0'])->get()):
                                ?>
                                <span style="width: 24px; font-size: 14px; height: 24px; background: #ff0000; color: #FFF; text-align: center; display: grid; align-items: center; border-radius: 100%; float: right;position: absolute;right: 15px;"><?=count($a)?></span>
                                <?php endif ?>
                            </a>
                            <a class="nav-link" href="<?=route('admin.sliders')?>">
                                <div class="sb-nav-link-icon"><i class="fas fa-book-open"></i></div>
                                Sliderlar
                            </a>
                            <a class="nav-link" href="<?=route('admin.pages')?>">
                                <div class="sb-nav-link-icon"><i class="fas fa-paper-plane"></i></div>
                                Sayfalar
                            </a>
                            <div class="sb-sidenav-menu-heading">AYARLAR</div>
                            <a class="nav-link" href="<?=route('admin.options')?>">
                                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                                Seçenekler
                            </a>
                        </div>
                    </div>
                    <div class="sb-sidenav-footer">
                        <div class="small">Giriş Yapıldı:</div>
                        <small>
                          <?php
                            echo user('email');
                          ?>
                        </small>
                    </div>
                </nav>
            </div>
            <div id="layoutSidenav_content">
                <main>
