        <div class="container-fluid px-4">
            <h1 class="mt-4">
              <?=sprintf("Gönderi No: #%08d", $i->id)?>
              <a href="<?=route('admin.print', ['id' => $i->id])?>" class="btn btn-primary float-right"><i class="fas fa-print"></i></a>
            </h1>

            <table class="table table-striped">
              <tbody>
                <?php
                foreach (json_decode($i->inputs, true) ?? [] as $k => $i)
                {
                  ?>
                  <tr>
                    <td width="50%"><b><?=$inputs[$k] ?? $k?>:</b></td>
                    <td width="50%"><?php
                       if (filter_var($i, FILTER_VALIDATE_URL))
                       {
                         if (preg_match('@(png|bmp|gif|jpg|jpeg)$@', $i))
                          echo sprintf("<img src='%s' style='max-height: 300px; width: auto; max-width: 300px'/>", $i);
                         else
                          echo sprintf("<a href='%s' target='_blank'>%s</a>", $i, $i);
                       }
                       else
                        echo $i;
                    ?></td>
                  </tr>
                  <?php
                }
                ?>
              </tbody>
            </table>

            <small style="margin-top: 24px; font-size: 12px; display: block; color: #CCC; font-style: italic"><?=date('d/m/Y H:i:s')?> tarihinde basıldı.</small>

        </div>

<style>
  body { font-family: sans-serif; }
  table {
    width: 100%;
    border-spacing: 0;
    border: 1px solid #DDD;
  }

  table th,
  table td {
    padding: 8px;
    border-bottom: solid;
    border-right: solid;
    border-width: 1px;
    border-color: #DDD;
  }

  table tr td:first-child {
    background: #EEE;
  }
</style>
<script type="text/javascript">
  window.onload = () => {
    print();
  }
</script>
