<?php
  $title = 'Görüntüle';
  include __DIR__ . '/partials/header.php';
?>

        <div class="container-fluid px-4">
            <h1 class="mt-4">
              <?=sprintf("Gönderi No: #%08d", $i->id)?>
              <a href="<?=route('admin.print', ['id' => $i->id])?>" class="btn btn-primary float-right"><i class="fas fa-print"></i></a>
            </h1>

            <table class="table table-striped">
              <tbody>
                <?php
                foreach (json_decode($i->inputs, true) ?? [] as $k => $i)
                {
                  ?>
                  <tr>
                    <td><b><?=$inputs[$k] ?? $k?>:</b></td>
                    <td><?php
                       if (filter_var($i, FILTER_VALIDATE_URL))
                       {
                         if (preg_match('@(png|bmp|gif|jpg|jpeg)$@', $i))
                          echo sprintf("<img src='%s' style='max-height: 300px; width: auto'/>", $i);
                         else
                          echo sprintf("<a href='%s' target='_blank'>%s</a>", $i, $i);
                       }
                       else
                        echo $i;
                    ?></td>
                  </tr>
                  <?php
                }
                ?>
              </tbody>
            </table>

        </div>

<?php
  include __DIR__ . '/partials/footer.php';
?>
