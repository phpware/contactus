<?php
  $title = 'Slider Ekle';
  include ENV_APP_DIR_APP . '/views/admin/partials/header.php';
?>

        <div class="container-fluid px-4">
            <h1 class="mt-4">Yeni Slider Ekle</h1>
            <form class="py-3" enctype="multipart/form-data" action="<?=route('admin.action.slider.add')?>" method="post">
              <?=csrfHiddenInput()?>
              <?php
                $flash = getFlash('error');
                if ($flash):
              ?>
              <div class="alert alert-danger">
                <?=$flash?>
              </div>
              <?php
                endif;
              ?>
              <div class="form-group mb-2">
                <label for="form-image" class="control-label">Slider Görseli:</label>
                <input id="form-image" type="file" accept=".png, .jpg, .jpeg, .bmp" class="form-control" name="image" required>
              </div>

              <div class="form-group mb-2">
                <label for="form-link" class="control-label">Link: (opsiyonel)</label>
                <input id="form-link" type="text" class="form-control" name="link">
              </div>

              <div class="form-group mb-2">
                <label for="form-top-title" class="control-label">Üst Başlık: (opsiyonel)</label>
                <input id="form-top-title" type="text" class="form-control" name="top-title">
              </div>

              <div class="form-group mb-2">
                <label for="form-big-title" class="control-label">Büyük Başlık: (opsiyonel)</label>
                <input id="form-big-title" type="text" class="form-control" name="big-title">
              </div>

              <div class="form-group mb-2">
                <label for="form-bottom-title" class="control-label">Alt Başlık: (opsiyonel)</label>
                <input id="form-bottom-title" type="text" class="form-control" name="bottom-title">
              </div>

              <div class="form-group mb-2">
                <label for="form-button-text" class="control-label">Düğme Yazısı: (opsiyonel)</label>
                <input id="form-button-text" type="text" class="form-control" name="button-text" value="Git">
              </div>

              <div class="form-group">
                <button type="submit" class="btn btn-primary btn-lg btn-block w-100">YENİ SLIDER OLUŞTUR</button>
              </div>

            </form>
        </div>

<?php
  include ENV_APP_DIR_APP . '/views/admin/partials/footer.php';
?>

<style media="screen">
  .float-left { float: left !important; }
  .text-right { text-align: right !important; display: inherit; }
</style>
<a id="top"></a>
