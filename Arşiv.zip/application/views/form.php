<?php
  include __DIR__ . '/partials/header.php';
?>

        <div id="about" class="page-section">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="section-heading">
                            <h4><?=$form->title?></h4>
                            <div class="line-dec"></div>
                        </div>
                    </div>
                </div>
                <form enctype="multipart/form-data" action="<?=route('action')?>" style="display: block" method="post">
                  <?php
                  csrfHiddenInput();
                  $flash = getFlash('success');
                  if ($flash):
                    ?>
                    <div class="alert alert-success">
                      <?=$flash?>
                    </div>
                    <?php
                  endif;

                  $flash = getFlash('error');
                  if ($flash):
                    ?>
                    <div class="alert alert-danger">
                      <?=$flash?>
                    </div>
                    <?php
                  endif;
                  ?>
                  <div class="row">
                    <input type="hidden" name="id" value="<?=$form->id?>">
                    <div class="service-item first-oo">
                    <?php
                      foreach (json_decode($form->inputs) as $input):
                    ?>
                      <div class="col-12" style="margin-bottom: 16px">
                              <h4 class="text-left"><?=$input->label?><?=$input->data->optional == 'on' ? ' (opsiyonel)' : null?></h4>
                              <?php
                              if (file_exists(VIEWS . "/inputs/{$input->type}.php"))
                                include VIEWS . "/inputs/{$input->type}.php";
                              ?>
                      </div>
                      <?php
                      endforeach;
                      ?>
                      <div class="form-group col-12">
                        <div class="row datacaptcha">
                          <div class="col-md-6">
                            <figure class="text-center">
                              <img src="<?=route('get-captcha')?>" alt="">
                            </figure>
                          </div>
                          <div class="col-md-6">
                            <input type="text" name="captcha" class="form-control" placeholder="Güvenlik Kodu" required>
                          </div>
                        </div>
                      </div>
                      <div class="col-12">
                        <button type="submit" class="btn btn-primary btn-block btn-lg">FORMU GÖNDER</button>
                      </div>
                    </div>
                  </div>
                </form>
            </div>
        </div>


<?php
  include __DIR__ . '/partials/footer.php';
?>
<style media="screen">
  .service-item:hover { cursor: default; background: #FFF; }
  .service-item:hover h4 { color: #000 !important; }
  .datacaptcha { width: 50%; margin: 0 auto; }
</style>
