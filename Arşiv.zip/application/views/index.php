<?php
  include __DIR__ . '/partials/header.php';
?>

    <section class="cd-hero">
        <ul class="cd-hero-slider autoplay">
        <!--
            <ul class="cd-hero-slider autoplay"> for slider auto play
            <ul class="cd-hero-slider"> for disabled auto play
        -->
            <?php
              foreach ($sliders as $first => $slider):
            ?>
            <li<?=$first === 0 ? ' class="selected"' : null?> style="background-image: url('<?=addslashes($slider->image)?>')">
                <div class="cd-full-width">
                    <div class="tm-slide-content-div slide-caption">
                        <?php if ($slider->span): ?><span><?=$slider->span?></span><?php endif ?>
                        <?php if ($slider->h2): ?><h2><?=$slider->h2?></h2><?php endif ?>
                        <?php if ($slider->title): ?><p><?=$slider->title?></p><?php endif ?>
                        <?php if ($slider->link && $slider->a): ?>
                        <div class="primary-button">
                            <a href="<?=$slider->link?>" class="scroll-link" data-id="about"><?=$slider->a?></a>
                        </div>
                        <?php endif ?>
                    </div>
                </div> <!-- .cd-full-width -->
            </li>
            <?php
              endforeach;
            ?>
        </ul> <!-- .cd-hero-slider -->

        <div class="cd-slider-nav">
            <nav>
                <span class="cd-marker item-1"></span>

                <ul>
                    <li class="selected"><a href="<?=asset('#0')?>"></a></li>
                </ul>
            </nav>
        </div> <!-- .cd-slider-nav -->
    </section> <!-- .cd-hero -->

<?php
  include __DIR__ . '/partials/footer.php';
?>
