<input type="checkbox"
       id="check-<?=$input->name?>"
       name="<?=$input->name?>"
       value="<?=$input->value?>"
       <?=old($input->name) ? 'checked' : null?>
       class="form-check-input <?=$input->class ?? ''?>"
       <?php
       foreach (json_decode($input->attributes ?? '[]') as $attr => $value):
       ?>
        <?=$attr?>="<?=trim(json_encode($value), '"')?>"
        <?php endforeach ?>
       <?=$input->data->optional != 'on' ? ' required' : null?>>

<label for="check-<?=$input->name?>" class="control-label"><?=$input->label?></label>
