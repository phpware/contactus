<input type="email"
       name="<?=$input->name?>"
       value="<?=old($input->name) ?? ($input->value ?? '')?>"
       class="form-control <?=$input->class ?? ''?>"
       <?=isset($input->placeholder) ? ' placeholder="'.trim(json_encode($input->placeholder), '"').'"' : null?>
       <?php
       foreach (json_decode($input->attributes ?? '[]') as $attr => $value):
       ?>
        <?=$attr?>="<?=trim(json_encode($value), '"')?>"
        <?php endforeach ?>
       <?=$input->data->optional != 'on' ? ' required' : null?>>
