<select class="form-control <?=$input->class ?? ''?>"
        name="<?=$input->name ?? ''?>"
        <?php
        foreach (json_decode($input->attributes ?? '[]') as $attr => $value):
        ?>
         <?=$attr?>="<?=trim(json_encode($value), '"')?>"
         <?php endforeach ?>
         <?=$input->data->optional != 'on' ? ' required' : null?>>
  <?php
  foreach (explode("\n", $input->data->datas) as $option):
  ?>
    <option value="<?=$option?>"><?=$option?></option>
  <?php endforeach ?>
</select>
