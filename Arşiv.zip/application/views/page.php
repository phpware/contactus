<?php
  include __DIR__ . '/partials/header.php';
?>

        <div id="about" class="page-section">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="section-heading">
                            <h4><?=$page->title?></h4>
                            <div class="line-dec"></div>
                        </div>
                    </div>
                </div>
                <?=nl2br(htmlspecialchars_decode($page->content))?>
            </div>
        </div>


<?php
  include __DIR__ . '/partials/footer.php';
?>
<style media="screen">
  .service-item:hover { cursor: default; background: #FFF; }
  .service-item:hover h4 { color: #000 !important; }
  .datacaptcha { width: 50%; margin: 0 auto; }
</style>
