<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title><?=$title?></title>
<!--

Template 2089 Meteor

http://www.tooplate.com/view/2089-meteor

-->
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="apple-touch-icon" href="<?=asset('apple-touch-icon.png')?>">

        <link rel="stylesheet" href="<?=asset('css/bootstrap.min.css')?>">
        <link rel="stylesheet" href="<?=asset('css/bootstrap-theme.min.css')?>">
        <link rel="stylesheet" href="<?=asset('css/fontAwesome.css')?>">
        <link rel="stylesheet" href="<?=asset('css/hero-slider.css')?>">
        <link rel="stylesheet" href="<?=asset('css/tooplate-style.css')?>">

        <link href="<?=asset('https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800')?>" rel="stylesheet">

        <script src="<?=asset('js/vendor/modernizr-2.8.3-respond-1.4.2.min.js')?>"></script>
    </head>

<body>
    <div class="header">
        <div class="container">
            <nav class="navbar navbar-inverse" role="navigation">
                <div class="navbar-header">
                    <button type="button" id="nav-toggle" class="navbar-toggle" data-toggle="collapse" data-target="#main-nav">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a href="<?=url('')?>" class="navbar-brand">
                        <div class="logo" style="background: url(<?=App\Models\Option::getBy('name', 'logo')->value?>)"></div>
                    </a>
                </div>
                <!--/.navbar-header-->
                <div id="main-nav" class="collapse navbar-collapse">
                    <ul class="nav navbar-nav">
                        <li><a href="<?=url('')?>">Ana Sayfa</a></li>
                        <?php
                          foreach($contacts as $contact):
                            if (!$contact->showOnMenu)
                              continue;
                        ?>
                        <li><a href="<?=route('form', ['slug' => $contact->slug])?>" class="scroll-link"><?=$contact->title?></a></li>
                        <?php endforeach;

                          foreach($pages as $page):
                            if (!$page->showOnMenu)
                              continue;
                        ?>
                        <li><a href="<?=route('form', ['slug' => $page->slug])?>" class="scroll-link"><?=$page->title?></a></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <!--/.navbar-collapse-->
            </nav>
            <!--/.navbar-->
        </div>
        <!--/.container-->
    </div>
    <!--/.header-->
