<?php

  return [

    'host' => 'localhost',
    'dbname' => 'contact',
    'user' => 'root',
    'pass' => 'root',

    'opts' => [
      PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES UTF8',
      PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
      PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_OBJ,
    ],

  ];
