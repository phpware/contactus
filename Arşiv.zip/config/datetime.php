<?php

  return [

    'current_timezone' => 'Europe/Istanbul',
    'current_locale' => 'tr_TR.UTF-8',

  ];
