<?php

  define('ENV_REQUEST_URI', getenv('REQUEST_URI'));
  define('ENV_REQUEST_METHOD', getenv('REQUEST_METHOD'));
  define('ENV_HOST_SSL', getenv('HTTPS'));
  define('ENV_APP_ROOT', getenv('DOCUMENT_ROOT'));
  define('ENV_APP_DIRECTORY', __DIR__);
  define('ENV_APP_URL', ((ENV_HOST_SSL ? 'https://' : 'http://') . getenv('HTTP_HOST') . '/' . preg_replace('@^'.preg_quote(ENV_APP_ROOT).'@', null, ENV_APP_DIRECTORY)));
  define('ENV_APP_DIR_APP', ENV_APP_DIRECTORY . '/application');
  define('ENV_APP_DIR_CONFIG', ENV_APP_DIRECTORY . '/config');
  define('ENV_CURRENT_URL', ENV_APP_URL . ENV_REQUEST_URI);

  require_once __DIR__ . '/vendor/autoload.php';
  require_once ENV_APP_DIR_APP . '/init.php';
